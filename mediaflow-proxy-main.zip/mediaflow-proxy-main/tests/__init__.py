# Extractor integration tests
